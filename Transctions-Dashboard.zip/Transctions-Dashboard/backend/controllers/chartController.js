const Transaction = require('../models/Transaction');

const getStatistics = async (req, res) => {
  try {
    const { month } = req.query;
    if (!month) {
      return res.status(400).json({ message: 'Month is required' });
    }

    const monthNumber = new Date(`${month} 1, 2000`).getMonth() + 1;

    const totalSales = await Transaction.aggregate([
      { $match: { sold: true, dateOfSale: { $month: monthNumber } } },
      { $group: { _id: null, totalSales: { $sum: "$price" } } },
    ]);

    const totalSoldItems = await Transaction.countDocuments({
      sold: true,
      dateOfSale: { $month: monthNumber },
    });

    const totalNotSoldItems = await Transaction.countDocuments({
      sold: false,
      dateOfSale: { $month: monthNumber },
    });

    res.json({
      totalSales: totalSales[0]?.totalSales || 0,
      totalSoldItems,
      totalNotSoldItems,
    });
  } catch (error) {
    console.error('Error fetching statistics:', error);
    res.status(500).json({ message: 'Internal server error', error: error.message });
  }
};

module.exports = { getStatistics };
