const axios = require('axios');
const Transaction = require('../models/Transaction');

async function seedDatabase() {
  try {
    const response = await axios.get('https://s3.amazonaws.com/roxiler.com/product_transaction.json');
    const data = response.data;
    await Transaction.insertMany(data);
    console.log('Data seeded successfully');
  } catch (error) {
    console.error('Error fetching/seeding data:', error);
  }
}

module.exports = seedDatabase;
