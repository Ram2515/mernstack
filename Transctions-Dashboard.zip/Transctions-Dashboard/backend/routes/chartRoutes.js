const express = require('express');
const { getStatistics } = require('../controllers/chartController');
const router = express.Router();

// Define the route for fetching statistics
router.get('/statistics', getStatistics);

module.exports = router;
