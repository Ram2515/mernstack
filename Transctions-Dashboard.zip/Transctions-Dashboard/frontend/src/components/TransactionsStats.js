import React, { useEffect, useState } from 'react';
import axios from 'axios';

function TransactionsStats({ month }) {
  const [stats, setStats] = useState({
    totalSaleAmount: 0,
    totalSoldItems: 0,
    totalNotSoldItems: 0
  });

  useEffect(() => {
    const fetchStats = async () => {
      const res = await axios.get(`/api/charts/statistics?month=${month}`);
      setStats(res.data);
    };
    fetchStats();
  }, [month]);

  return (
    <div className="stats">
      <div>Total Sale Amount: ${stats.totalSaleAmount}</div>
      <div>Total Sold Items: {stats.totalSoldItems}</div>
      <div>Total Not Sold Items: {stats.totalNotSoldItems}</div>
    </div>
  );
}

export default TransactionsStats;
