import React from 'react';

function SearchBox({ setSearchTerm }) {
  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  return (
    <div className="search-box">
      <input
        type="text"
        placeholder="Search transactions..."
        onChange={handleSearch}
      />
    </div>
  );
}

export default SearchBox;
