import React, { useState } from 'react';
import TransactionsTable from './components/TransactionsTable';
import TransactionsStats from './components/TransactionsStats';
import TransactionsChart from './components/TransactionsChart';
import SearchBox from './components/SearchBox';
import './App.css';

function App() {
  const [month, setMonth] = useState('March');
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <div className="App">
      <h1>Product Transactions</h1>
      <div className="controls">
        <label htmlFor="monthSelect">Select Month:</label>
        <select id="monthSelect" onChange={(e) => setMonth(e.target.value)} value={month}>
          {['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'].map((monthOption) => (
            <option key={monthOption} value={monthOption}>
              {monthOption}
            </option>
          ))}
        </select>
      </div>
      <SearchBox setSearchTerm={setSearchTerm} />
      <TransactionsTable month={month} searchTerm={searchTerm} />
      <TransactionsStats month={month} />
      <TransactionsChart month={month} />
    </div>
  );
}

export default App;
